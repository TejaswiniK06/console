﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIMSExceptionLayer
{
    public class MyException : ApplicationException
    {
        public MyException() : base() { }

        public MyException(string message) : base(message) { }

        public MyException(string message, Exception innerException) : base(message, innerException) { }
    }
    
    
}
