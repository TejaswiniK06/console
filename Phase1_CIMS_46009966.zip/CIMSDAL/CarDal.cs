﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CIMSEntities;
using CIMSExceptionLayer;
using System.IO;

using System.Runtime.Serialization.Formatters.Binary;

namespace CIMSDAL
{
    public class CarDal
    {
        public static List<CarEntities> CarList = new List<CarEntities>();
        public static List<Manufacturer> ManfactureList = new List<Manufacturer>();
        public static List<CarType> CarTypeList = new List<CarType>();
        public static List<CarTransmissionType> TransmissionTypes = new List<CarTransmissionType>();
        public static string fileName = "ListOfCars";
        public static string fileName1 = "ListOfManufacturers";
        public static string fileName2 = "ListOfCarTypes";
        public static string fileName3 = "ListOfTransmissionTypes";

        public static bool AddCarDAL(CarEntities car)
        {
            bool IsCarAdded = false;
            try
            {
                CarList.Add(car);
                IsCarAdded = true;
                SetSerialization1();
            }
            catch (MyException ex)
            {
                throw new MyException(ex.Message);
            }
            return IsCarAdded;

        }
        public static bool AddManfDAL(Manufacturer manf)
        {
            bool IsManfAdded = false;
            try
            {
                ManfactureList.Add(manf);
                IsManfAdded = true;
                SetSerialization1();
            }
            catch (MyException ex)
            {
                throw new MyException(ex.Message);
            }
            return IsManfAdded;

        }
        public static bool AddTypeDAL(CarType car)
        {
            bool IsTypeAdded = false;
            try
            {
                CarTypeList.Add(car);
                IsTypeAdded = true;
                SetSerialization1();
            }
            catch (MyException ex)
            {
                throw new MyException(ex.Message);
            }
            return IsTypeAdded;

        }
        public static void SetlistDL()
        {
            
            DSerialize();
        }

        public static bool AddTransDAL(CarTransmissionType car)
        {
            bool IsTransAdded = false;
            try
            {
                TransmissionTypes.Add(car);
                IsTransAdded = true;
                SetSerialization1();
            }
            catch (MyException ex)
            {
                throw new MyException(ex.Message);
            }
            return IsTransAdded;

        }

        
        private static void SetSerialization1()
        {
            try
            {
                using (Stream file = File.Open(fileName, FileMode.Create))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(file, CarList);

                    file.Close();
                }

                using (Stream file = File.Open(fileName1, FileMode.Create))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(file, ManfactureList);

                    file.Close();
                }
                using (Stream file = File.Open(fileName3, FileMode.Create))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(file, TransmissionTypes);

                    file.Close();
                }
                using (Stream file = File.Open(fileName2, FileMode.Create))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(file, CarTypeList);

                    file.Close();
                }
            }
            catch (MyException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void DSerialize()
        {
            try
            {
                using (Stream file = File.Open(Directory.GetCurrentDirectory() + "\\" + fileName, FileMode.Open))
                {
                    BinaryFormatter bf = new BinaryFormatter();

                    CarList = bf.Deserialize(file) as List<CarEntities>;
                    file.Close();
                }

                using (Stream file = File.Open(Directory.GetCurrentDirectory() + "\\" + fileName1, FileMode.Open))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    ManfactureList = bf.Deserialize(file) as List<Manufacturer>;

                    file.Close();
                }

                using (Stream file = File.Open(Directory.GetCurrentDirectory() + "\\" + fileName2, FileMode.Open))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    CarTypeList = bf.Deserialize(file) as List<CarType>;

                    file.Close();
                }

                using (Stream file = File.Open(Directory.GetCurrentDirectory() + "\\" + fileName3, FileMode.Open))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    TransmissionTypes = bf.Deserialize(file) as List<CarTransmissionType>;

                    file.Close();
                }
            }
            catch (MyException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static CarEntities SearchVehicleByModelDAL(string model)
        {
            CarEntities searchVehicle = null;
            try
            {


                for (int i = 0; i < CarList.Count; i++)
                {
                    CarEntities car = CarList[i];
                    if (car.Model == model)
                    {
                        searchVehicle = CarList[i];
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new MyException(ex.Message);
            }
            return searchVehicle;
        }
        public static int SearchManfIdDAL(string model)
        {
            int ManfId = 0;
            try
            {


                for (int i = 0; i < ManfactureList.Count; i++)
                {
                    Manufacturer car = ManfactureList[i];
                    if (car.Name == model)
                    {
                        ManfId = car.Id;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new MyException(ex.Message);
            }
            return ManfId;
        }

        public static int SearchTypeIdDAL(string type)
        {
            int TypeId = 0;
            try
            {


                for (int i = 0; i < CarTypeList.Count; i++)
                {
                    CarType car = CarTypeList[i];
                    if (car.TypeOfCar == type)
                    {
                        TypeId = car.Id;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new MyException(ex.Message);
            }
            return TypeId;

        }
        public static List<CarEntities> GetAllVehicleDL()
        {
            return CarList;
        }
        public static int SearchTransIdDAL(string trans)
        {
            int TransId = 0;
            try
            {


                for (int i = 0; i < TransmissionTypes.Count; i++)
                {
                    CarTransmissionType car = TransmissionTypes[i];
                    if (car.TransmissionType == trans)
                    {
                        TransId = car.Id;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new MyException(ex.Message);
            }
            return TransId;
        }

        public static CarEntities SearchByModelDAL(string model)
        {
            CarEntities searchVehicle = null;
            try
            {
                for (int i = 0; i < CarList.Count; i++)
                {
                    CarEntities vehicle = CarList[i];
                    if (vehicle.Model == model)
                    {
                        searchVehicle = CarList[i];
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new MyException(ex.Message);
            }
            return searchVehicle;
        }

        public static CarEntities SearchByManufDAL(string manfname,string cartype)
        {
            CarEntities searchCar = null;
            try
            {
                for (int i = 0; i < CarList.Count; i++)
                {
                    CarEntities car = CarList[i];
                    if (car.ManufacturerName == manfname && car.Type == cartype)
                    {
                        searchCar = CarList[i];
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new MyException(ex.Message);
            }
            return searchCar;
        }


        public static bool UpdateVehicleDAL(CarEntities updatecar)
        {
            bool carupdated = false;
            try
            {
                for (int i = 0; i < CarList.Count(); i++)
                {
                    if (updatecar == CarList[i])
                    {
                        CarList[i].Model = updatecar.Model;
                        CarList[i].Type = updatecar.Type;
                        CarList[i].ManufacturerName = updatecar.ManufacturerName;
                        CarList[i].Engine = updatecar.Engine;
                        CarList[i].BHP = updatecar.BHP;
                        CarList[i].Transmission = updatecar.Transmission;
                        CarList[i].Mileage = updatecar.Mileage;
                        CarList[i].Seats = updatecar.Seats;
                        CarList[i].Airbags = updatecar.Airbags;
                        CarList[i].BootSpace = updatecar.BootSpace;
                        CarList[i].ManufacturerId = updatecar.ManufacturerId;
                        CarList[i].TypeId = updatecar.TypeId;
                        CarList[i].TransmissionId = updatecar.TransmissionId;
                        CarList[i].Price = updatecar.Price;
                        SetSerialization1();
                        break;
                    }
                }

                carupdated = true;
            }
            catch (Exception ex)
            {
                throw new MyException(ex.Message);
            }
            return carupdated;
        }
        public static bool DeleteCarDAL(string modelremove)
        {

            bool removed = false;
            try
            {
                for (int i = 0; i < CarList.Count; i++)
                {
                    CarEntities car = CarList[i];
                    if (car.Model == modelremove)
                    {
                        CarList.RemoveAt(i);
                        removed = true;
                        SetSerialization1();
                        break;
                    }
                }


            }
            catch (MyException ex)
            {
                throw ex;
            }
            return removed;
        }


    }
}
